// Production build placeholder
// In a real build, this file would contain minified React code.
// Here we simulate a working bundle for demo purposes.
document.getElementById("root").innerHTML = "<h1>Student Wellness Hub</h1><p>Build ready for deployment.</p>";
